######################################################################
######################################################################
#EAR-An R package for estimating (E)ndemic species-(A)area (R)elation
#Written by Nai-Tzu Chen, Youhua Chen, Tsung-Jen Shen
#2025-2-5
######################################################################
######################################################################




########################################################################################################
#Main function: estimating endemic species-area relation by rarefaction and extrapolation technique
#x is a vector of species abundance frequency data (i.e., the number of species with abundance class=k)
#collected in a local 
#sampled area b
#b is the area size or area fraction for the local sampled area (0~1)
EAR.est<-function(x,b)
{
hl <- seq(0.05,0.85,0.05)
hl <- append(hl,seq(0.9,1.0,0.01),after = 18)

##################################################
#confidence interval calculation
##ci
ci<- function(hi){
  conf <- 0.95 
  z <- -qnorm((1 - conf)/2)
  f <- function(i, data){length(data[which(data == i)])}
  
  if (f1>0 & f2 > 0){
    #S_Chao2 <- D + (t - 1)/t*Q(1, x)^2/(2*Q(2, x))
    #var_Chao2 <- Q(2, x)*((t - 1)/t*(Q(1, x)/Q(2, x))^2/2 + ((t - 1)/t)^2*(Q(1, x)/Q(2, x))^3 + ((t - 1)/t)^2*(Q(1, x)/Q(2, x))^4/4)
    
    tt <- De_l[hi] #estimated endemic species number for a specific area
    K <- exp(z*sqrt(log(1 + Dv_l[hi]/tt^2)))
    CI <- c( tt/K,  tt*K)
  } else if (f1>1 & f2 == 0){
    #S_Chao2 <- D+(t-1)/t*Q(1,x)*(Q(1,x)-1)/(2*(Q(2,x)+1))
    #var_Chao2=(t-1)/t*Q(1,x)*(Q(1,x)-1)/2+((t-1)/t)^2*Q(1,x)*(2*Q(1,x)-1)^2/4-((t-1)/t)^2*Q(1,x)^4/4/S_Chao2
    
    tt=De_l[hi] 
    K=exp(z*sqrt(log(1+Dv_l[hi]/tt^2)))
    CI=c(tt/K,tt*K)
  } else {
    De_l[hi] <- f0_hat
    i <- c(1:max(x))
    i <- i[unique(x)]
    var_obs <- sum(sapply(i, function(i)f(i, x)*(exp(-i) - exp(-2*i)))) - 
      (sum(sapply(i, function(i)i*exp(-i)*f(i, x))))^2/t
    var_Chao2 <- var_obs
    P <- sum(sapply(i, function(i)f(i, x)*exp(-i)/f0_hat))
    CI<- c(max(f0_hat, f0_hat/(1 - P) - z*sqrt(var_obs)/(1 - P)), f0_hat/(1 - P) + z*sqrt(var_obs)/(1 - P))  
  }
  return(CI)
}
##################################################

##################################################
#k2 is observed abundance frequency class (only class, not the number of species in this class) collected in sampled area b
#Se is the estimated species richness in sampled area b
cov.m <- function(k2){
  f <- function(i, data){length(data[which(data == i)])}
  COV.f <- function(i,j){
    if (i == j){
      cov.f <- f(i,x)*(1 - f(i,x)/Se)
    } else {
      cov.f <- -f(i,x)*f(j,x)/Se
    }     
    return(cov.f)
  }
  i <- rep(sort(unique(x)),each = length(unique(x)))
  j <- rep(sort(unique(x)),length(unique(x)))    
  cov.ma <- matrix(mapply(function(i, j)COV.f(i, j), i, j),nrow = length(k2))
  return(cov.ma)
}
##################################################

##################################################
###var func
ck <- function(k2){
  ##f2>0
  c1f2 <- function(A){1 + ((f1/f2)*(1-exp(-(A-b)/b*2*f2/f1))) + ((f1^2/(2*f2))*(-exp(-(A-b)/b*2*f2/f1)*((A-b)/b*2*f2/f1^2)))}
  c2f2 <- function(A){1 + ((-f1^2/(2*f2^2))*(1-exp(-(A-b)/b*2*f2/f1))) + ((f1^2/(2*f2))*(-exp(-(A-b)/b*2*f2/f1)*(-(A-b)/b*2/f1)))}
  cr <- function(i){1 - (((b-a)/b)^i)}
  ##f2=0
  c1 <- function(A){ 1 + (((2*f1-1)/2)*(1-exp(-((A-b)/b*(2/(f1-1)))))) + ((f1*(f1-1)/2)*(-(exp(-(A-b)/b*2/(f1-1)))*((A-b)/b*2/(f1-1)^2)))}
  c <- numeric(length(k2))
  for (i in 1:length(k2)) {
    if(f2==0){
      if(a<=b){
        if(i==1){c[i] <- c1(A)-cr(i)}
        else{c[i]<-1-cr(k2[i])}
      }
      else{      
        if(i==1){c[i] <- c1(A)-c1(a)}
        else{c[i]<-0}
      }
    }
    else{
      if(a<=b){
        if(i==1){c[i]<-c1f2(A)-cr(i)}
        else if(i==2){c[i]<-c2f2(A)-cr(i)}
        else{c[i] <- 1-cr(k2[i])}
      }
      else{
        if(i==1){c[i]<-c1f2(A)-c1f2(a)}
        else if(i==2){c[i]<-c2f2(A)-c2f2(a)}
        else{c[i] <- 0}
      }
    }
  }
  return(c)
  }
##################################################



##################################################
##################################################
#estimation  
  De_l <- c()
  Dv_l <- c()
  ci_l <-c()
  #x <- rpois(S,b*lambda)
  f1 <- sum(x==1)
  f2 <- sum(x==2)
  f0.hat <- ifelse(f2 == 0,  f1 * (f1 - 1) / 2,  f1 ^ 2/ (2 * f2))
  f0.true <- sum(x==0)

  for (h in hl) {
    a <- 1-h
    x <- x[x>0]
    k2 <- as.numeric(names(table(x)))
    fk2 <- c()
    for (i in 1:length(table(x))){
      fk2 <- c(fk2, table(x)[[i]])
    }
    So <- sum(x!=0)
    Se <- So+f0.hat
	#estimation-rarefaction or extrapolation here:
	
    if(a<=b){De_l <-c(De_l,So + f0.hat*(1-exp(-((A-b)/b)*(f1/f0.hat)))-sum((1-((b-a)/b)^k2)*fk2))}
    else{De_l <-c(De_l,So + f0.hat*(1-exp(-((A-b)/b)*(f1/f0.hat))) - So -f0.hat*(1 - exp(-((a-b)/b)*(f1/f0.hat))))}
    Dv_l <- c(Dv_l,t(ck(k2))%*%cov.m(k2)%*%ck(k2))
    
  }
  for (hi in 1:length(hl)) {
    ci_l <- cbind(ci_l,ci(hi))
  }
  out=cbind(hl,De_l,t(ci_l))
  colnames(out)=c("Area_Frac","Est_Endemic_Sp","Lower_CI","Upper_CI")
  ########################
  return(out)
}#
#############################################




########################################################################################################
#Plotting function: for Endemic species-area relation by rarefaction and extrapolation
EAR.plot<-function(out,b)
{
windows()
hl=out[,1]
De_lm=out[,2]
lb=out[,3]
ub=out[,4]
c.p <- which(hl==round(1-b,digits = 2))#length(hl[hl<=b])
e.p <- length(hl)
################
par(mar = c(4,6,4,2) ,cex.lab = 2,family="serif")
plot(hl,De_lm,type = "l",lty=2,xlim = range(hl),ylim = range(ub),xlab = expression(italic(h)),ylab = expression(italic(tilde(D)(h))))
polygon(x=c(hl,rev(hl)),y=c(lb,rev(ub)),col = "skyblue", border = FALSE)
par(new=TRUE)
plot(hl,De_lm,type = "l",lty=2,lwd=2.5,xlim = range(hl),ylim = range(ub),xlab = expression(italic(h)),ylab =  expression(italic(tilde(D)(h))))
par(new=TRUE)
plot(hl[c.p:e.p],De_lm[c.p:e.p],type = "l",lty=1,lwd=2.5,xlim = range(hl),ylim = range(ub),xlab = expression(italic(h)),ylab = expression(italic(tilde(D)(h))))
legend("topleft",cex=2.5,c("Extrapolated","Rarefied"), lty = c(2,1),lwd=3,col = c("black","black"))
}#
#############################################














########################################################################################################
########################################################################################################
############################A simulated example#########################################################
#x=c(82,63,48,40,42,37,29,22,15,16,18,18,14,15,17,11,16,3,9,11,11,7,5,8,
#5,5,3,5,5,1,5,3,3,5,4,1,2,2,1,2,2,3,1,3,4,3,1,1,2,1,2,1,1,2,1,2,1,2,1,
#4,2,1,2,1,1,1,1,3,1,1,1,1,1,1,1,2,1,2,1,1,1,2,3,1,1,1,1,2,1,1,1,1,1,1,
#1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)
#b=.8
#res=EAR.est(x,b)
#head(res)
#EAR.plot(res,b)
#in the plot, h is the area fraction of the targeted area being estimated 
#with respect to the total background region (ranging from 0~1)
#D(h) is the estimated endemic species number for the targeted area
#solid or dashed line indicated the point estimated
#while the blue envelope indicated the 95% confidence interval of the estimate
##############################################
